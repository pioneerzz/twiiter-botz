module.exports = function (name) {
  return (



// insert your greeting message
`
Hey ${name},

Thanks for following me! ${String.fromCodePoint(0x1F60E)}
`
//



  )
}